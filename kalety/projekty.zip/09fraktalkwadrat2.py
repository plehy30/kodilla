from turtle import *
from math import sqrt
speed(0)
kolor1="blue"
kolor2="yellow"
def kwadrat(x,y,d,kol):
    fillcolor(kol)
    goto(x,y)
    begin_fill()
    for i in range(4):
        fd(d)
        rt(90)
    end_fill()

def dywan

pu()
goto(-200,-200)
seth(90)
kwadrat( 0,0,200,kolor1,kolor2)

mainloop()
